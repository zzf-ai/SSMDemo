create
    definer = root@localhost function mock_data1() returns int
begin
	declare num int default 10;
    declare i int default 0;
    while i<num do
		insert into blog (id,author,title,createTime,view) 
		values(uuid(),concat('作者',i),concat('标题',i),current_timestamp,floor(rand()*9999));
		set i=i+1;
	end while;
    return i;
end;

