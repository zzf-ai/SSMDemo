create
    definer = root@localhost function mock_data() returns int
begin
	declare num int default 10;
    declare i int default 0;
    while i<num do
		insert into student (id,sname,tid) 
		values(i+1,concat('用户',i),1);
		set i=i+1;
	end while;
    return i;
end;

